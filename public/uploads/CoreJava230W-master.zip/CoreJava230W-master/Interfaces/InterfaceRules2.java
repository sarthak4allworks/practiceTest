interface B1
{
	
}
interface B2 extends B1{
	
}
class C1{
	
}
class C2 extends C1 implements B2{
	
}
public class InterfaceRules2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
