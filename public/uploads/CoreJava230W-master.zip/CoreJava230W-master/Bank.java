
public class Bank {
	
	public void withDraw(){
		checkPin();
		checkAccountLocked();
		checkNoOfTrans();
		checkBalance();
	}
	
	private void checkNoOfTrans(){
		
	}
	
	private void checkAccountLocked(){
		
	}
	
	private void checkBalance(){
		
	}
	
	private void checkPin(){
		
	}

}
