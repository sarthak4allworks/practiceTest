class IfElseDemo
{
public static void main(String args[])
{
boolean x = false;
 int a  = 1000;
int b = 200;
//System.out.println(a>b);

//if(x=true)
if(a=10)
{
System.out.println("A is Greater ");
}
else
{
System.out.println("B is Greater ");
}

}
}