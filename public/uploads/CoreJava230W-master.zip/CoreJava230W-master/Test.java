// OOP + API
public class Test {

	public static void main(String[] args) {
		// ram is a instance of Employee Class
		// shyam ref var + local var + object
		Employee shyam = new Employee(1001,"Shyam",9999);
		//shyam = new Employee();
		shyam.print();
		System.out.println("****************************8");
		Employee ram = new Employee(1002,"Ram",7777);
		ram.print();
		
		/*shyam.id = -1001;
		shyam.name="      ";
		shyam.salary=-9000;*/
		
		//shyam.takeInput(111, "Shyam", 9090);
		
		
		/*System.out.println("*********************************");
		
		Employee ram = new Employee();
		ram.takeInput(1001, "Ram", 5454);
		ram.print();*/
		
		/*shyam.id = 111;
		shyam.name = "Shyam";
		shyam.salary= 9009.0;*/
		
		
		/*System.out.println("Id "+ram.id);
		System.out.println("Name "+ram.name);
		System.out.println("Salary "+ram.salary);*/
		/*ram.id = 191;
		ram.name="Ram Kumar";
		ram.salary= 9090;
		System.out.println("***********************************");
		ram.print();
		*//*System.out.println("Id "+ram.id);
		System.out.println("Name "+ram.name);
		System.out.println("Salary "+ram.salary);*/
		//int x = 200;
		
		//System.out.println("Hello Java");

	}

}
