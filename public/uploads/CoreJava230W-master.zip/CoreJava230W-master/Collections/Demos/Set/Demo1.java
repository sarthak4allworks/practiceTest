import java.util.TreeSet;


public class Demo1 {

	public static void main(String[] args) {
		TreeSet<String> hs = new TreeSet<String>();
		hs.add("ram");
		hs.add("mike");
		hs.add("ram");
		hs.add("mike");
		hs.add("ram");
		hs.add("shyam");
		System.out.println(hs);
		
	}

}
