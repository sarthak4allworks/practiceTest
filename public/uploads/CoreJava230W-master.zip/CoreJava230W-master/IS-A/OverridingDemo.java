class T1
{
	private final void show(){
		System.out.println("T1 Show");
	}
}
class T2 extends T1{
	
	 void show(){
		System.out.println("T2 Show");
	}
}
public class OverridingDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
