
public class A {

	public static void main(String[] args) throws Exception {
		//BEntry obj = new B();
		BEntry obj = ObjectFactory.createObject();
		obj.show();
	}

}
