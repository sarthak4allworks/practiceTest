
public class A2 {

	public static void main(String[] args)throws Exception {
		BEntry obj = ObjectFactory.createObject();
		obj.show();
	}

}
