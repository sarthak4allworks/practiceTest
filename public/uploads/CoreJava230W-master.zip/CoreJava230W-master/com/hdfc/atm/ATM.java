package com.hdfc.atm;

import com.hdfc.banking.Bank;

public class ATM {
public static void main(String[] args) {
	Bank bank = new Bank();
	bank.withDraw();
}
}
